var searchData=
[
  ['hadc1_0',['hadc1',['../adc_8h.html#a22b804736f5648d52f639b2647d4ed13',1,'hadc1():&#160;adc.c'],['../adc_8c.html#a22b804736f5648d52f639b2647d4ed13',1,'hadc1():&#160;adc.c']]],
  ['hdma_5fadc1_1',['hdma_adc1',['../adc_8c.html#a1c126854bb1813d31ab4776b21dcc51f',1,'hdma_adc1():&#160;adc.c'],['../stm32g4xx__it_8c.html#a1c126854bb1813d31ab4776b21dcc51f',1,'hdma_adc1():&#160;adc.c']]],
  ['htim1_2',['htim1',['../tim_8h.html#a25fc663547539bc49fecc0011bd76ab5',1,'htim1():&#160;tim.c'],['../tim_8c.html#a25fc663547539bc49fecc0011bd76ab5',1,'htim1():&#160;tim.c']]],
  ['huart2_3',['huart2',['../usart_8h.html#aa9479c261d65eecedd3d9582f7f0f89c',1,'huart2():&#160;usart.c'],['../stm32g4xx__it_8c.html#aa9479c261d65eecedd3d9582f7f0f89c',1,'huart2():&#160;usart.c'],['../usart_8c.html#aa9479c261d65eecedd3d9582f7f0f89c',1,'huart2():&#160;usart.c']]]
];
