var searchData=
[
  ['_5f_5fsbrk_5fheap_5fend_0',['__sbrk_heap_end',['../sysmem_8c.html#a2cf862d604e9c7cfcf0528a0f539a6a5',1,'sysmem.c']]]
];
