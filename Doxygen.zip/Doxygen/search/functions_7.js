var searchData=
[
  ['imp_0',['Imp',['../_commande_8h.html#ab5de887c526b3039f4d721ff26a7808c',1,'Imp(void):&#160;Commande.c'],['../_commande_8c.html#a75c9d47fd97ab5415509ca984e5e7969',1,'Imp():&#160;Commande.c']]],
  ['initialise_5fmonitor_5fhandles_1',['initialise_monitor_handles',['../syscalls_8c.html#a25c7f100d498300fff65568c2fcfe639',1,'syscalls.c']]]
];
