var searchData=
[
  ['usagefault_5fhandler_0',['UsageFault_Handler',['../stm32g4xx__it_8h.html#a1d98923de2ed6b7309b66f9ba2971647',1,'UsageFault_Handler(void):&#160;stm32g4xx_it.c'],['../stm32g4xx__it_8c.html#a1d98923de2ed6b7309b66f9ba2971647',1,'UsageFault_Handler(void):&#160;stm32g4xx_it.c']]],
  ['usart2_5firqhandler_1',['USART2_IRQHandler',['../stm32g4xx__it_8h.html#a0ca6fd0e6f77921dd1123539857ba0a8',1,'USART2_IRQHandler(void):&#160;stm32g4xx_it.c'],['../stm32g4xx__it_8c.html#a0ca6fd0e6f77921dd1123539857ba0a8',1,'USART2_IRQHandler(void):&#160;stm32g4xx_it.c']]]
];
