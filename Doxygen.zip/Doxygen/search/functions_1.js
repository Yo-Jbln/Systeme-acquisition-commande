var searchData=
[
  ['affprompt_0',['affprompt',['../_commande_8h.html#a18b2a990b607fdb0c7a4a8238131264e',1,'affprompt(void):&#160;Commande.c'],['../_commande_8c.html#a774cb48fea525d540b313b9e14c1c4ef',1,'affprompt():&#160;Commande.c']]],
  ['alphachange_1',['Alphachange',['../_commande_8h.html#aa1225a30f9fbcf9a09c7045e47002eba',1,'Alphachange(int):&#160;Commande.c'],['../_commande_8c.html#af2fe7599b8c3593fd826072c03846d6b',1,'Alphachange(int newalpha):&#160;Commande.c']]]
];
