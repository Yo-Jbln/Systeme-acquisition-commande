var searchData=
[
  ['uart_5frx_5fbuffer_0',['uart_rx_buffer',['../main_8c.html#a8cf6f55cf4735df9d67b1bb52f6f861b',1,'main.c']]],
  ['uart_5ftx_5fbuffer_1',['uart_tx_buffer',['../main_8c.html#aa93aa9d1693aa2349621dafaa4414beb',1,'main.c']]]
];
