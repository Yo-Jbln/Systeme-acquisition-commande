var indexSectionsWithContent =
{
  0: "_abcdeghilmnopstuv",
  1: "acdgmstu",
  2: "_abcdehimnopsu",
  3: "_abcehipsu",
  4: "_abcdehilptuv",
  5: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros",
  5: "Modules"
};

