var searchData=
[
  ['cmd_5fbuffer_5fsize_0',['CMD_BUFFER_SIZE',['../main_8c.html#a8a0465f8e8bbe71e4d6e8011e975bf75',1,'main.c']]]
];
